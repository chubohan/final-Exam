package imd.ntub.mybottonnav

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.fragment.app.setFragmentResultListener
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FirstFragment : Fragment() {
    private lateinit var userRepository: UserRepository
    private lateinit var users: ArrayList<User>
    private lateinit var myAdapter: MyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        userRepository = UserRepository(requireContext())
        users = ArrayList(userRepository.getAllUsers())
    }

    class MyAdapter(private val data: ArrayList<User>, private val fragment: Fragment) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {
        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val imageView: ImageView = view.findViewById(R.id.imageView)
            val txtName: TextView = view.findViewById(R.id.txtName)
            val txtPhone: TextView = view.findViewById(R.id.txtPhone)
            val imageButton: ImageButton = view.findViewById(R.id.imageButton)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.adapter_row, parent, false))
        }

        override fun getItemCount() = data.size

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val currentUser = data[position]
            holder.txtName.text = currentUser.name
            holder.txtPhone.text = currentUser.phone

            holder.txtName.setOnClickListener {
                val bundle = bundleOf(
                    "user" to currentUser,
                    "position" to position
                )
                fragment.setFragmentResult("editUserRequestKey", bundle)
            }

            holder.imageView.setOnClickListener {
                val intent = Intent(Intent.ACTION_DIAL)
                intent.data = Uri.parse("tel:" + currentUser.phone)
                it.context.startActivity(intent)
            }

            holder.imageButton.setOnClickListener {
                AlertDialog.Builder(it.context)
                    .setMessage("确定要删除此联系人吗？")
                    .setPositiveButton("确定") { _, _ ->
                        data.removeAt(position)
                        (fragment as FirstFragment).userRepository.deleteUser(currentUser.id)
                        notifyDataSetChanged()
                    }
                    .setNegativeButton("取消", null)
                    .show()
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        myAdapter = MyAdapter(users, this)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = myAdapter

        // 监听来自 SecondFragment 的结果
        setFragmentResultListener("addUserRequestKey") { _, bundle ->
            val user = bundle.getParcelable<User>("user")
            user?.let {
                users.add(it)
                myAdapter.notifyDataSetChanged()
            }
        }

        // 监听来自 SecondFragment 的编辑结果
        setFragmentResultListener("editUserResultKey") { _, bundle ->
            val user = bundle.getParcelable<User>("user")
            val position = bundle.getInt("position", -1)
            user?.let {
                if (position != -1 && position < users.size) {
                    users[position] = it
                    myAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    fun addUser(user: User) {
        users.add(user)
        myAdapter.notifyDataSetChanged()
    }

    fun updateUser(user: User, position: Int) {
        if (position != -1 && position < users.size) {
            users[position] = user
            myAdapter.notifyDataSetChanged()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_first, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() = FirstFragment()
    }
}